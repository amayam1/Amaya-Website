// Loading data
const iris = d3.csv("iris.csv");

iris.then(function(data) {
    // Converting string values to numbers
    data.forEach(function(d) {
        d.PetalLength = +d.PetalLength;
        d.PetalWidth = +d.PetalWidth;
    });

    // Scatter plot 
    const margin = { top: 40, right: 30, bottom: 50, left: 60 };
    const width = 600 - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;

    const svg = d3.select("#scatterplot")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);
    
    const xScale = d3.scaleLinear()
        .domain([d3.min(data, d => d.PetalLength) - 0.5, d3.max(data, d => d.PetalLength) + 0.5])
        .range([0, width]);

    const yScale = d3.scaleLinear()
        .domain([d3.min(data, d => d.PetalWidth) - 0.5, d3.max(data, d => d.PetalWidth) + 0.5])
        .range([height, 0]);

    const colorScale = d3.scaleOrdinal()
        .domain(data.map(d => d.Species))
        .range(d3.schemeCategory10);

    svg.append("g")
        .attr("transform", `translate(0,${height})`)
        .call(d3.axisBottom(xScale));

    svg.append("g")
        .call(d3.axisLeft(yScale));

    svg.selectAll("circle")
        .data(data)
        .enter()
        .append("circle")
        .attr("cx", d => xScale(d.PetalLength))
        .attr("cy", d => yScale(d.PetalWidth))
        .attr("r", 5)
        .style("fill", d => colorScale(d.Species))
        .style("opacity", 0.7);

    svg.append("text")
        .attr("x", width / 2)
        .attr("y", height + margin.bottom - 10)
        .attr("text-anchor", "middle")
        .text("Petal Length");

    svg.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height / 2)
        .attr("y", -margin.left + 15)
        .attr("text-anchor", "middle")
        .text("Petal Width");

    const legend = svg.selectAll(".legend")
        .data(colorScale.domain())
        .enter().append("g")
        .attr("class", "legend")
        .attr("transform", (d, i) => `translate(0,${i * 20})`);

    legend.append("circle")
        .attr("cx", width + 10)
        .attr("cy", 10)
        .attr("r", 5)
        .style("fill", colorScale);

    legend.append("text")
        .attr("x", width + 20)
        .attr("y", 10)
        .attr("dy", "0.35em")
        .style("text-anchor", "start")
        .text(d => d);

    // Boxplot code
    const svgBoxplot = d3.select("#boxplot")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    const xScaleBox = d3.scaleBand()
        .domain([...new Set(data.map(d => d.Species))])
        .range([0, width])
        .padding(0.4);

    const yScaleBox = d3.scaleLinear()
        .domain([d3.min(data, d => d.PetalLength) - 1, d3.max(data, d => d.PetalLength) + 1])
        .range([height, 0]);

    svgBoxplot.append("g")
        .attr("transform", `translate(0,${height})`)
        .call(d3.axisBottom(xScaleBox));

    svgBoxplot.append("g")
        .call(d3.axisLeft(yScaleBox));

    svgBoxplot.append("text")
        .attr("x", width / 2)
        .attr("y", height + margin.bottom - 10)
        .attr("text-anchor", "middle")
        .text("Species");

    svgBoxplot.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height / 2)
        .attr("y", -margin.left + 15)
        .attr("text-anchor", "middle")
        .text("Petal Length");

    const rollupFunction = function(groupData) {
        const values = groupData.map(d => d.PetalLength).sort(d3.ascending);
        const q1 = d3.quantile(values, 0.25);
        const median = d3.quantile(values, 0.5);
        const q3 = d3.quantile(values, 0.75);
        return { q1, median, q3 };
    };

    const quartilesBySpecies = d3.rollup(data, rollupFunction, d => d.Species);
    console.log("Quartiles by species:", quartilesBySpecies); // Debugging log
//This line groups data by Species and applies the rollupFunction to calculate q1, median, and q3 for petal length in each group
    quartilesBySpecies.forEach((quartiles, species) => {
        const x = xScaleBox(species);
        const boxWidth = xScaleBox.bandwidth();
//This starts a loop over each species to plot its boxplot. x is the horizontal position of the species on the x axis, and boxWidth is the width of each box
        const iqr = quartiles.q3 - quartiles.q1;
        const lowerWhisker = Math.max(d3.min(data, d => d.PetalLength), quartiles.q1 - 1.5 * iqr);
        const upperWhisker = Math.min(d3.max(data, d => d.PetalLength), quartiles.q3 + 1.5 * iqr);

        svgBoxplot.append("line")
            .attr("x1", x + boxWidth / 2)
            .attr("x2", x + boxWidth / 2)
            .attr("y1", yScaleBox(lowerWhisker))
            .attr("y2", yScaleBox(upperWhisker))
            .attr("stroke", "pink");

        svgBoxplot.append("rect")
            .attr("x", x)
            .attr("y", yScaleBox(quartiles.q3))
            .attr("width", boxWidth)
            .attr("height", yScaleBox(quartiles.q1) - yScaleBox(quartiles.q3))
            .attr("fill", "green")
            .attr("stroke", "pink");

        svgBoxplot.append("line")
            .attr("x1", x)
            .attr("x2", x + boxWidth)
            .attr("y1", yScaleBox(quartiles.median))
            .attr("y2", yScaleBox(quartiles.median))
            .attr("stroke", "pink");
    });
});
